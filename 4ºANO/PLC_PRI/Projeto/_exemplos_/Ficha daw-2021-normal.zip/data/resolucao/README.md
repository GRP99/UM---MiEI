# DAW2020TESTE
		
		Resolução do teste prático de Desenvolvimento de aplicações Web (20-01-2021)
